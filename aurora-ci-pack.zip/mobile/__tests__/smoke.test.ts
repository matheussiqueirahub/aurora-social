test('smoke', () => expect(true).toBe(true));
